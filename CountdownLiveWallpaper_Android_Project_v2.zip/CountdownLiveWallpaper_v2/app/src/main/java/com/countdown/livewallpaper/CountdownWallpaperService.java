package com.countdown.livewallpaper;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class CountdownWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new CountdownEngine();
    }

    private class CountdownEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean visible = false;

        private final Runnable drawRunnable = new Runnable() {
            @Override public void run() {
                drawFrame();
                if (visible) handler.postDelayed(this, 1000);
            }
        };

        CountdownEngine() {
            paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
            linePaint.setStrokeWidth(2f);
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (isVisible) {
                drawFrame();
                handler.removeCallbacks(drawRunnable);
                handler.post(drawRunnable);
            } else {
                handler.removeCallbacks(drawRunnable);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (visible) drawFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            super.onDestroy();
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;

                final int w = canvas.getWidth();
                final int h = canvas.getHeight();

                // Deep navy -> warm horizon background.
                LinearGradient bg = new LinearGradient(
                        0, 0, 0, h,
                        Color.rgb(3, 17, 32),
                        Color.rgb(31, 29, 24),
                        Shader.TileMode.CLAMP);
                paint.setShader(bg);
                canvas.drawRect(0, 0, w, h, paint);
                paint.setShader(null);

                // Subtle horizon glow.
                paint.setShader(new LinearGradient(
                        0, h * 0.55f, 0, h * 0.9f,
                        Color.argb(0, 255, 190, 90),
                        Color.argb(70, 255, 170, 70),
                        Shader.TileMode.CLAMP));
                canvas.drawRect(0, h * 0.45f, w, h, paint);
                paint.setShader(null);

                float cx = w / 2f;
                float top = h * 0.15f;

                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));

                drawText(canvas, "THE COUNTDOWN TO", cx, top, h * 0.022f, Color.rgb(238, 238, 238));
                drawText(canvas, "22 SEPTEMBER 2026", cx, top + h * 0.065f, h * 0.040f, Color.rgb(232, 177, 91));
                drawText(canvas, "STAY FOCUSED • EVERY SECOND COUNTS", cx, top + h * 0.105f, h * 0.018f, Color.rgb(215, 215, 215));

                // Countdown calculation uses the phone's current timezone.
                java.util.Calendar target = java.util.Calendar.getInstance();
                target.set(java.util.Calendar.YEAR, 2026);
                target.set(java.util.Calendar.MONTH, java.util.Calendar.SEPTEMBER);
                target.set(java.util.Calendar.DAY_OF_MONTH, 22);
                target.set(java.util.Calendar.HOUR_OF_DAY, 0);
                target.set(java.util.Calendar.MINUTE, 0);
                target.set(java.util.Calendar.SECOND, 0);
                target.set(java.util.Calendar.MILLISECOND, 0);

                long diff = target.getTimeInMillis() - System.currentTimeMillis();
                if (diff < 0) diff = 0;

                long days = TimeUnit.MILLISECONDS.toDays(diff);
                long hours = TimeUnit.MILLISECONDS.toHours(diff) % 24;
                long minutes = TimeUnit.MILLISECONDS.toMinutes(diff) % 60;
                long seconds = TimeUnit.MILLISECONDS.toSeconds(diff) % 60;

                float boxTop = h * 0.32f;
                float boxBottom = h * 0.61f;

                paint.setColor(Color.argb(105, 0, 0, 0));
                canvas.drawRoundRect(w * 0.075f, boxTop, w * 0.925f, boxBottom,
                        28, 28, paint);

                linePaint.setColor(Color.argb(210, 232, 177, 91));
                canvas.drawRoundRect(w * 0.075f, boxTop, w * 0.925f, boxBottom,
                        28, 28, linePaint);

                drawText(canvas, "COUNTDOWN", cx, boxTop + h * 0.055f, h * 0.020f, Color.WHITE);

                float[] xs = {w * 0.19f, w * 0.405f, w * 0.62f, w * 0.81f};
                String[] values = {
                        String.valueOf(days),
                        String.format(Locale.US, "%02d", hours),
                        String.format(Locale.US, "%02d", minutes),
                        String.format(Locale.US, "%02d", seconds)
                };
                String[] labels = {"DAYS", "HOURS", "MINUTES", "SECONDS"};

                for (int i = 0; i < 4; i++) {
                    drawText(canvas, values[i], xs[i], boxTop + h * 0.145f,
                            h * 0.043f, Color.WHITE);
                    drawText(canvas, labels[i], xs[i], boxTop + h * 0.205f,
                            h * 0.014f, Color.rgb(232, 177, 91));
                    if (i < 3) {
                        linePaint.setColor(Color.argb(90, 230, 230, 230));
                        canvas.drawLine(xs[i] + w * 0.105f, boxTop + h * 0.09f,
                                xs[i] + w * 0.105f, boxBottom - h * 0.05f, linePaint);
                    }
                }

                drawText(canvas, "Every second brings you closer.", cx,
                        boxBottom - h * 0.025f, h * 0.018f, Color.rgb(235, 235, 235));

                // Minimal mountain silhouette.
                paint.setColor(Color.argb(225, 5, 12, 20));
                android.graphics.Path mountain = new android.graphics.Path();
                mountain.moveTo(0, h);
                mountain.lineTo(0, h * 0.79f);
                mountain.lineTo(w * 0.18f, h * 0.69f);
                mountain.lineTo(w * 0.34f, h * 0.79f);
                mountain.lineTo(w * 0.50f, h * 0.62f);
                mountain.lineTo(w * 0.66f, h * 0.79f);
                mountain.lineTo(w * 0.83f, h * 0.70f);
                mountain.lineTo(w, h * 0.79f);
                mountain.lineTo(w, h);
                mountain.close();
                canvas.drawPath(mountain, paint);

                drawText(canvas, "FOCUS • PLAN • BELIEVE • ACHIEVE", cx,
                        h * 0.91f, h * 0.017f, Color.rgb(232, 177, 91));
                drawText(canvas, "DISCIPLINE TODAY, SUCCESS TOMORROW", cx,
                        h * 0.95f, h * 0.014f, Color.WHITE);

            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }

        private void drawText(Canvas c, String text, float x, float y, float size, int color) {
            paint.setShader(null);
            paint.setColor(color);
            paint.setTextSize(size);
            paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
            c.drawText(text, x, y, paint);
        }
    }
}
