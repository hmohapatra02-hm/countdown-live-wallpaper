# 22 September 2026 Countdown Live Wallpaper — v2

This version includes a normal app icon. Open the app and it automatically opens the Android live-wallpaper setting screen for the countdown wallpaper.

Target: 22 September 2026 at 00:00 in the phone's current timezone.
