# 22 September 2026 Countdown — Android Live Wallpaper

A simple Android Live Wallpaper that counts down to **22 September 2026 at 00:00**, using the phone's current date/time and timezone.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or start an emulator.
4. Run the `app` configuration.
5. Android will install the app.
6. Open Android's **Wallpaper / Live Wallpaper** picker and select **22 September 2026 Countdown**.

## Important
The countdown target is midnight at the start of 22 September 2026 in the phone's current timezone. The display refreshes every second while the live wallpaper is visible.

## Project
- Language: Java
- Min Android: 6.0 (API 23)
- Target/Compile SDK: 35
- No internet permission
- No analytics or ads
